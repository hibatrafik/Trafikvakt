import os
import re
import time
import json
import hashlib
from datetime import datetime
from pathlib import Path

from dotenv import load_dotenv
from twilio.rest import Client
from playwright.sync_api import sync_playwright, TimeoutError as PWTimeoutError

load_dotenv()

BOOKING_URL = os.getenv("BOOKING_URL", "").strip()
if not BOOKING_URL:
    raise SystemExit("Saknar BOOKING_URL i .env – fyll i den exakta sidan där tiderna syns.")

POLL_INTERVAL_SEC = int(os.getenv("POLL_INTERVAL_SEC", "60"))
HEADLESS = os.getenv("HEADLESS", "true").lower() == "true"
USER_DATA_DIR = os.getenv("USER_DATA_DIR", "playwright-user-data")
TIMES_CONTAINER_SELECTOR = os.getenv("TIMES_CONTAINER_SELECTOR", "").strip() or None

TWILIO_ACCOUNT_SID = os.getenv("TWILIO_ACCOUNT_SID", "").strip()
TWILIO_AUTH_TOKEN = os.getenv("TWILIO_AUTH_TOKEN", "").strip()
TWILIO_FROM = os.getenv("TWILIO_FROM", "").strip()
TWILIO_TO = os.getenv("TWILIO_TO", "").strip()

if not all([TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_FROM, TWILIO_TO]):
    raise SystemExit("Saknar Twilio-uppgifter i .env (TWILIO_*).")

client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)

STATE_FILE = Path("state.json")

def send_sms(message: str):
    try:
        client.messages.create(
            body=message,
            from_=TWILIO_FROM,
            to=TWILIO_TO
        )
        print(f"[{timestamp()}] SMS skickat.")
    except Exception as e:
        print(f"[{timestamp()}] Misslyckades skicka SMS: {e}")

def timestamp():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def sha1(text: str) -> str:
    return hashlib.sha1(text.encode("utf-8", "ignore")).hexdigest()

def extract_times(text: str):
    # Hitta tider som 07:00–23:59
    return sorted(set(re.findall(r"\b(?:[01]?\d|2[0-3]):[0-5]\d\b", text)))

def read_state():
    if STATE_FILE.exists():
        try:
            return json.loads(STATE_FILE.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}

def write_state(state: dict):
    STATE_FILE.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")

def main():
    print(f"Startar bevakning mot: {BOOKING_URL}")
    print(f"Intervall: {POLL_INTERVAL_SEC}s, Headless: {HEADLESS}, Profil: {USER_DATA_DIR}")
    state = read_state()
    last_hash = state.get("last_hash", "")
    last_times = set(state.get("last_times", []))

    with sync_playwright() as p:
        browser = p.chromium.launch_persistent_context(
            user_data_dir=USER_DATA_DIR,
            headless=HEADLESS,
            args=["--disable-dev-shm-usage"]
        )
        page = browser.new_page()

        while True:
            try:
                page.goto(BOOKING_URL, wait_until="networkidle", timeout=90000)

                text = ""
                if TIMES_CONTAINER_SELECTOR:
                    try:
                        page.wait_for_selector(TIMES_CONTAINER_SELECTOR, timeout=20000)
                        el = page.query_selector(TIMES_CONTAINER_SELECTOR)
                        text = (el.inner_text() if el else "")
                    except PWTimeoutError:
                        text = ""
                if not text:
                    # Fallback: hela sidan
                    text = page.inner_text("body")

                current_hash = sha1(text)
                times = set(extract_times(text))

                if current_hash != last_hash:
                    # Innehållet har förändrats – skicka larm
                    # Om vi hittar klockslag, inkludera dem i SMS för tydlighet
                    if times:
                        new_times = ", ".join(sorted(times))
                        msg = f"Lediga (eller ändrade) tider hittade! Klockslag: {new_times}\nGå till: {BOOKING_URL}"
                    else:
                        msg = f"Sidan har uppdaterats – kolla tiderna NU!\n{BOOKING_URL}"

                    print(f"[{timestamp()}] Förändring upptäckt. Skickar SMS.")
                    send_sms(msg)
                    last_hash = current_hash
                    last_times = list(times)
                    write_state({"last_hash": last_hash, "last_times": list(times)})
                else:
                    # Ingen ändring – men om nya tider dyker upp utan att resten av sidan ändrats, larma ändå
                    if times and set(times) != set(last_times):
                        new_only = sorted(set(times) - set(last_times))
                        if new_only:
                            msg = f"Nya klockslag upptäckta: {', '.join(new_only)}\n{BOOKING_URL}"
                            print(f"[{timestamp()}] Nya tider jämfört med tidigare. Skickar SMS.")
                            send_sms(msg)
                            last_times = list(times)
                            write_state({"last_hash": last_hash, "last_times": list(times)})
                        else:
                            print(f"[{timestamp()}] Små tidsändringar men inga nya tider.")
                    else:
                        print(f"[{timestamp()}] Ingen förändring.")

            except PWTimeoutError:
                print(f"[{timestamp()}] Timeout vid laddning – försöker igen.")
            except Exception as e:
                print(f"[{timestamp()}] Fel: {e}")

            time.sleep(POLL_INTERVAL_SEC)

if __name__ == "__main__":
    main()
