# Slot Watcher – SMS för lediga körprovstider (Trafikverket)

**Gör:** bevakar en sida där tider visas och skickar **SMS** direkt när den hittar tillgängliga tider.
**Gör inte:** bokar åt dig. Du bokar själv så fort du får SMS:et.

> Tips: Kör först 10–20 minuter med ett rimligt intervall (t.ex. `60`) för att se att allt funkar, innan du låter den rulla dygnet runt.

---

## 1) Installera
**Windows / macOS / Linux (kräver Python 3.10+):**
```bash
cd slot_watcher_sms
pip install -r requirements.txt
python -m playwright install
```

## 2) Konfigurera
1. Kopiera `.env.example` till `.env` och fyll i:
   - `TWILIO_*` (konto, token, from- och to-nummer)
   - `BOOKING_URL` – **EXAKT** sidan där tiderna visas för din ort/datum/vecka.
   - (valfritt) `TIMES_CONTAINER_SELECTOR` om du vill peka ut själva listan.
2. Första gången: sätt `HEADLESS=false` i `.env` så att ett fönster öppnas och du kan logga in med BankID/Min sida om det krävs.
   - Efter inloggning stänger du programmet. Starta om med `HEADLESS=true` så kommer sessionen att återanvändas.

## 3) Kör
```bash
python slot_watcher.py
```
Du ser logg i terminalen. När boten hittar tider skickas SMS, och du får även en tydlig loggrad.

## 4) Kör dygnet runt
### Linux (systemd):
Skapa en servicefil (exempel finns i `systemd/slot-watcher.service`). Uppdatera sökvägar och användare, sedan:
```bash
sudo cp systemd/slot-watcher.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now slot-watcher
sudo journalctl -u slot-watcher -f
```

### Windows (Task Scheduler):
- Skapa en "Basic Task" som kör: `python` med argument `slot_watcher.py` i mappen.
- Ställ "Repeat task every" till 1 minut **avstängt** (boten själv loopar), och "Run whether user is logged on or not".

### macOS (launchd):
- Använd `launchctl` med en plist som kör `python slot_watcher.py` vid inloggning (boten loopar själv).

## 5) Tips & felsökning
- **Etik & belastning**: använd `POLL_INTERVAL_SEC >= 60` för att vara snäll mot tjänsten.
- **Selectors**: Om boten inte hittar tider, öppna devtools (högerklick → Inspect) och ange en unik CSS-selektor för listan i `.env`.
- **Duplicerade SMS**: Boten minimerar dubletter genom att bara larma vid **nytt innehåll** (ändrat sidinnehåll eller nya tider).
- **Reset**: Rensa mappen i `USER_DATA_DIR` om inloggningen strular.

## 6) Juridik & villkor
Läs och följ Trafikverkets användarvillkor. Använd på egen risk. Den här koden är för personligt bruk och bokar **inte** automatiskt.
